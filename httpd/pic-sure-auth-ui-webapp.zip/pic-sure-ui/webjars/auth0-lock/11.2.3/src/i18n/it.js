export default {
  error: {
    forgotPassword: {
      too_many_requests:
        'Hai raggiunto il limite di tentativi di modifica della password . Attendi prima di riprovare.',
      'lock.fallback':
        'Ci dispiace, qualcosa è andato storto durante la richiesta di modifica della password.'
    },
    login: {
      blocked_user: 'L’utente è bloccato.',
      invalid_user_password: 'Credenziali non corrette.',
      'lock.fallback': 'Ci dispiace, qualcosa è andato storto quando si tenta di accedere.',
      'lock.invalid_code': 'Codice errato.',
      'lock.invalid_email_password': 'email o password sbagliata.',
      'lock.invalid_username_password': 'Nome utente o password sbagliata.',
      'lock.network':
        'Non siamo riusciti a raggiungere il server. Si prega di controllare la connessione e riprovare.',
      'lock.popup_closed': 'Finestra popup chiusa. Riprova per favore.',
      'lock.unauthorized': 'Autorizzazioni non concesse. Riprova per favore.',
      password_change_required:
        'È necessario aggiornare la password perché questa è il primo login, o perché la password è scaduta.',
      password_leaked:
        'Questo accesso è stato bloccato perché la password è trapelato in un altro sito . Ti abbiamo inviato una email con le istruzioni su come sbloccarla.',
      too_many_attempts:
        'Il suo account è stato bloccato dopo vari tentativi di accesso consecutivi.',
      'lock.mfa_registration_required':
        'Autenticazione a più fattori richiesta, ma il dispositivo non è abilitato. Si prega di iscriversi prima di passare.',
      'lock.mfa_invalid_code': 'Codice errato. Riprova.',
      session_missing:
        'Impossibile completare la richiesta di autenticazione. Riprova dopo aver chiuso tutte le finestre di dialogo aperte',
      'hrd.not_matching_email':
        'Si prega di utilizzare la posta elettronica aziendale per effettuare il login.'
    },
    passwordless: {
      'bad.email': 'L’email non è valido ',
      'bad.phone_number': 'Il numero di telefono non è valido',
      'lock.fallback': 'Ci dispiace, qualcosa è andato storto'
    },
    signUp: {
      invalid_password: 'La password non è valida.',
      'lock.fallback': "Ci dispiace, qualcosa è andato storto quando si tenta l'iscrizione.",
      password_dictionary_error: 'La password è troppo comune.',
      password_no_user_info_error: "La password si basa sulle informazioni dell'utente.",
      password_strength_error: 'La password è troppo debole.',
      user_exists: 'L’utente esiste già.',
      username_exists: 'Il nome utente esiste già.'
    }
  },
  success: {
    logIn: 'Grazie per il login.',
    forgotPassword: 'Abbiamo appena inviato un email per reimpostare la password.',
    magicLink: 'La abbiamo inviato un link per il login <br />a %s.',
    signUp: 'Grazie per esserti iscritto.'
  },
  blankErrorHint: 'Non può essere vuoto',
  codeInputPlaceholder: 'il Suo codice',
  databaseEnterpriseLoginInstructions: '',
  databaseEnterpriseAlternativeLoginInstructions: 'o',
  databaseSignUpInstructions: '',
  databaseAlternativeSignUpInstructions: 'o',
  emailInputPlaceholder: 'email@esempio.com',
  enterpriseLoginIntructions: 'Effettuare il login con le credenziali aziendali.',
  enterpriseActiveLoginInstructions: 'Si prega di inserire le credenziali aziendali a  %s.',
  failedLabel: 'Fallito!',
  forgotPasswordAction: 'Non ricordi la password?',
  forgotPasswordInstructions:
    "Inserisci l'email. Ti invieremo una email per reimpostare la password.",
  forgotPasswordSubmitLabel: "Inviare l'email",
  invalidErrorHint: 'Non valido',
  lastLoginInstructions: 'L’ultima volta hai effettuato l’accesso con',
  loginAtLabel: 'Accedere a %s',
  loginLabel: 'Accesso',
  loginSubmitLabel: 'Accesso',
  loginWithLabel: 'Accedi con %s',
  notYourAccountAction: 'Non è il tuo account?',
  passwordInputPlaceholder: 'La sua password',
  passwordStrength: {
    containsAtLeast: 'Essa deve contenere almeno %d dei seguenti %d tipi di caratteri:',
    identicalChars: 'Non più di %d caratteri identici in una fila (e.g., "%s" non autorizzato)',
    nonEmpty: "E'richiesta una password non vuota",
    numbers: 'Numeri (i.e. 0-9)',
    lengthAtLeast: 'Almeno %d caratteri di lunghezza',
    lowerCase: 'Lettere minuscole (a-z)',
    shouldContain: 'Dovrebbe contenere:',
    specialCharacters: 'Caratteri speciali (e.g. !@#$%^&*)',
    upperCase: 'Caratteri maiuscoli (A-Z)'
  },
  passwordlessEmailAlternativeInstructions:
    "Altrimenti, si prega d’inserire l'email per accedere <br/> o creare un account",
  passwordlessEmailCodeInstructions: 'Una email con il codice è stato inviata %s.',
  passwordlessEmailInstructions: 'Si prega d’inserire la email <br/>o creare un account',
  passwordlessSMSAlternativeInstructions:
    'Altrimenti, si prega d’inserire il numero di telefono per accedere <br/>o creare un account',
  passwordlessSMSCodeInstructions: 'Un SMS con il codice è stato inviato<br/> a %s.',
  passwordlessSMSInstructions: 'Si prega d’inserire il numero di telefono <br/>o creare un account',
  phoneNumberInputPlaceholder: 'il Suo numero di telefono',
  resendCodeAction: 'Non hai ottentuo il codice?',
  resendLabel: 'Inviare di nuovo',
  resendingLabel: 'Reinvio...',
  retryLabel: 'Riprovare per favore',
  sentLabel: 'Inviato!',
  signUpLabel: 'Registrazione',
  signUpSubmitLabel: 'Registrazione',
  signUpTerms: '',
  signUpWithLabel: 'Registra con %s',
  socialLoginInstructions: '',
  socialSignUpInstructions: '',
  ssoEnabled: 'Single Sign-On abilitati',
  submitLabel: 'Invio',
  unrecoverableError: 'Qualcosa è andato storto.<br />Si prega di contattare il supporto tecnico.',
  usernameFormatErrorHint: 'Usa %d-%d lettere, numeri ei seguenti caratteri: "_", ".", "+", "-"',
  usernameInputPlaceholder: 'Nome utente',
  usernameOrEmailInputPlaceholder: 'Nome utente o email',
  title: 'Auth0',
  welcome: 'Benvenuto %s!',
  windowsAuthInstructions: 'Si è connessi dalla rete aziendale&hellip;',
  windowsAuthLabel: 'Autenticazione Windows',
  forgotPasswordTitle: 'Reimposta la tua password',
  signupTitle: 'Registrazione',
  mfaInputPlaceholder: 'Codice',
  mfaLoginTitle: '2-fase di verifica',
  mfaLoginInstructions:
    'Si prega di inserire il codice di verifica generato dalla tua applicazione mobile.',
  mfaSubmitLabel: 'Accesso',
  mfaCodeErrorHint: 'Usare %d numeri',
  showPassword: 'Mostra password'
};
