export default {
  lastUsedConnection: {
    strategy: 'auth0',
    name: 'db'
  },
  lastUsedUserID: 'auth0|5676890e2a64397e7e0d773c',
  lastUsedUsername: 'someone@auth0.com',
  lastUsedClientID: 'L9kBZOpEbLizzCGv6N8n9wNfQhbvREw0',
  sessionClients: ['L9kBZOpEbLizzCGv6N8n9wNfQhbvREw0'],
  sso: true
};
