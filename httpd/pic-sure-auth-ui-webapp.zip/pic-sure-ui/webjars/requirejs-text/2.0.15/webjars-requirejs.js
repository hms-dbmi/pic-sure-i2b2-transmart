requirejs.config({
    paths: {
        "text": webjars.path("requirejs-text", "text")
    }
});
